# Total Music

An extension for Twitch.tv to play music from the audience end to avoid DMCA issues for streamers

Planned to be released in September.



## License
[MIT](https://choosealicense.com/licenses/mit/)


broadcaster side:
live_config.html 
css/live.css
js/main.js

viewer side:
video_component.html
css/viewer.css


lambda.js is the server side stuff (hosted on AWS)
js/viewer.js

everything else is just helper files