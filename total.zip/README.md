# Total Music

An extension for Twitch.tv to play music from the audience end to avoid DMCA issues for streamers

Planned to be released in September.

## License
[MIT](https://choosealicense.com/licenses/mit/)