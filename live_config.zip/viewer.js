

// var twitch = window.Twitch.ext;

// var requests = {
//     set: createRequest('POST', 'cycle'),
// };

// function createRequest(type, method) {

//     return {
//         type: type,
//         url: 'localhost:3000',
//         headers: {
        	
//         }
//         success: updateBlock,
//         error: logError
//     }
// }


$(function() {
	var url = "";
	window.Twitch.ext.listen("broadcast", (x,y,data) => {
		console.log(data);
		$("#vid").attr("src", data);
		$("#vid")[0].load();
		document.getElementById("vid").play();
	});
});