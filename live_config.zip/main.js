
$(function() {
	var url = "";
	var ret;
	var nextUrl = "";
	var isPlaylist = false;
	var playlistUrlList = []; 
	var pos = 0;
	var linkSent = "";

	//update config player
	window.Twitch.ext.listen("broadcast", (x,y,data) => {
		console.log(data);
		$("#vid").attr("src", data);
		$("#vid")[0].load();
		document.getElementById("vid").play();
	});


	// document.getElementById('vid').addEventListener('timeupdate', updateCountdown ,false);
 //    function myHandler(e) {
 //    	var timeLeft = Math.round(video.duration) - Math.round(video.currentTime);
 //    	if (timeLeft >)
 //    	getLink(nextUrl);
 //    }

	//got to next vid if current one ended
	document.getElementById('vid').addEventListener('ended', hadEnded ,false);
    async function hadEnded(e) {
		window.Twitch.ext.send("broadcast", "string", url);
		await getLink(nextUrl);
    }


    async function getLink(link){
		AWS.config.update({accessKeyId: 'AKIAJPACPXZ5WGQRB3MQ', secretAccessKey: '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'});
		if (!AWS.config.region) {
		  AWS.config.update({
		    region: 'us-east-2'
		  });
		}
		var lambda = new AWS.Lambda();
		var params = {

		  FunctionName: 'testFunc', /* required */

		  Payload: JSON.stringify(link),

		};

		await lambda.invoke(params, function(err, data) {

		  if (err) console.log(err, err.stack);

		}).promise().then(data => {
			ret = JSON.parse(JSON.parse(JSON.stringify(data.Payload)))

			if (!isPlaylist){
				//single vid
				url = ret[0]
				nextUrl = ret[1]
				$("#url").text(url);
			} else if (isPlaylist) {
				//playlist vids
				url = ret[0]
				pos++;
				if (pos < playlistUrlList.length){
					nextUrl = playlistUrlList[pos]
				} else {
					nextUrl = playlistUrlList[0]
				}
				$("#url").text(url);
			} else {
				//is a playlist
				isPlaylist = true;
				playlistUrlList = ret;
				if (link.split("index=").length == 2){
					pos = link.split("index=")[1];
				}
				else {
					pos = 0;
				}
				getLink(playlistUrlList[pos]);
			}
		});
    }


  $('#submit').click(async function() {
  		const youLink = $('#link')[0].value.toString();
  		isPlaylist = false;
		await getLink(youLink);
		if (!isPlaylist){
			window.Twitch.ext.send("broadcast", "string", url);	
		}
		await getLink(nextUrl);
  });
});

//    global.fetch("https://peaceful-savannah-35663.herokuapp.com/" + self._opts.url, {


// $(async function() {
// 	const youLink = "https://www.youtube.com/watch?v=hnW7fhUsq4o";
// 	console.log(youLink)
//     var x = await ytdl.getInfo(youLink);
//     console.log(x.formats[0].url);
// });


// async function getLink(link) {
// 	var temp = "";
// 	// console.log(link);
// 	let info = await ytdl.getInfo(link);
//     temp = info.formats[0].url;
// 	return temp;
// }

	// var prom = new Promise((resolve, reject) => {
	// 	console.log(link);
	//     let info = ytdl.getInfo(link, function (err, info){
	//     	console.log(link);
	//     	if (err) throw (err);
	// 	    console.log(info.formats[0].url);
	// 	    temp = info.formats[0].url;
	// 		resolve(temp);
	//     });
	// });
	// return prom;
// }

// async function temp() {
// 	const youLink = $('#link')[0].value;
//     const prom = new Promise((resolve, reject) => {
// 		const info = ytdl.getInfo(youLink, async (err, info) => {
// 			if (err) reject(err);
// 			// console.log(payload.link);
// 			console.log(info.formats[0].url);
// 		    resolve(info.formats[0].url); //you can store it here
// 		});
// 	});
// 	return prom;
// }